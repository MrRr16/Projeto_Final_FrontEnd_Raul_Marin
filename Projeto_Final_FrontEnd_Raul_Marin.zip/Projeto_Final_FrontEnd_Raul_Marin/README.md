
## Estrutura visual do site

```text
[ Navbar: Marca | Início | Serviços | Tecnologias | Projetos | Dúvidas | Contato ]
+----------------------------------------------------------------+
| BANNER: Web • IA • Cloud                                      |
| Curitiba • Florianópolis • Porto Alegre                       |
| Sites • Sistemas • Automações                                 |
| HTML • CSS • JavaScript • Python                              |
+----------------------------------------------------------------+
| SERVIÇOS                                                      |
| [card][card][card]                                            |
| [card][card][card]                                            |
+----------------------------------------------------------------+
| TECNOLOGIAS                                                   |
+----------------------------------------------------------------+
| SOBRE A EMPRESA                                               |
+----------------------------------------------------------------+
| PROJETOS + GALERIA + VÍDEO                                    |
+----------------------------------------------------------------+
| DÚVIDAS (Accordion)                                            |
+----------------------------------------------------------------+
| CONTATO: [formulário] | [WhatsApp][E-mail][Localização][Redes]|
+----------------------------------------------------------------+
| FOOTER                                                         |
+----------------------------------------------------------------+
```